import requests
import os
import subprocess

# İndirme URL'si
url = "https://download.pytorch.org/whl/torch/torch-2.5.1+cpu-cp313-cp313-win_amd64.whl"

# İndirme hedef yolu
file_name = url.split("/")[-1]  # Dosya adını URL'den alır
download_path = os.path.join(os.getcwd(), file_name)  # Mevcut dizine kaydet

# Dosyayı indirme
print(f"İndiriliyor: {url}")
response = requests.get(url, stream=True)
if response.status_code == 200:
    with open(download_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                f.write(chunk)
    print(f"Dosya indirildi: {download_path}")
else:
    print(f"İndirme başarısız oldu! Status code: {response.status_code}")
    exit(1)

# pip ile kurulum
print("Kurulum başlatılıyor...")
try:
    subprocess.check_call(["pip", "install", download_path])
    print("Kurulum tamamlandı!")
except subprocess.CalledProcessError as e:
    print(f"Kurulum sırasında bir hata oluştu: {e}")
